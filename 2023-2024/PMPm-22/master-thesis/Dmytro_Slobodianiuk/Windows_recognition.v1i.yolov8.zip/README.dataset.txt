# Windows_recognition > 2024-05-13 1:23pm
https://universe.roboflow.com/lviv-national-university-of-ivan-franko/windows_recognition

Provided by a Roboflow user
License: CC BY 4.0

